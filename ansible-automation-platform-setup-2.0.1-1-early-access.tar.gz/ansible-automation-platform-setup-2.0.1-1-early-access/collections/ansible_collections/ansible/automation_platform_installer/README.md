# Ansible Collection - ansible.automation_platform_installer

This collection contains the roles necessary to install the
Red Hat Automation Controller.
